My Photo Gallery Pro - Web App

ফাইলগুলো HTTPS ওয়েব হোস্টিংয়ে (যেমন GitHub Pages) আপলোড করলে Chrome-এ লিংক দিয়ে চলবে।
index.html একা খুললেও basic gallery চলবে, কিন্তু PWA/offline cache-এর জন্য HTTPS hosting প্রয়োজন।

সীমাবদ্ধতা:
- PIN lock এই ব্রাউজারে লোকাল PIN gate; এটি encrypted vault নয়।
- Fingerprint biometric lock এই সংস্করণে সক্রিয় নয়।
- Android Chrome-এর Web Share সমর্থন করলে ফাইল Facebook Share Sheet-এ পাঠানো যায়।
  Profile বা Page বেছে নেওয়া Facebook app-এর ওপর নির্ভরশীল; Page-এ পোস্ট নিশ্চিত নয়।
- ব্রাউজারের data/site storage মুছে ফেললে IndexedDB-তে রাখা ফাইল হারাতে পারে।
- কোনো ZIP Export feature নেই।
